function [ n ] = szDict( ob )
%SZDICT Size of dictionary
%   n = szDict(ob)

% Housen Li @ IMS
% 2020-09-15 created

n = ob.nbf;


end

